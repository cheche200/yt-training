package com.marcoas99.youtubescraper.repository;

import com.marcoas99.youtubescraper.model.Channel;
import lombok.AllArgsConstructor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;


@DataJpaTest
@EnableJpaRepositories(basePackages = "com.marcoas99.youtubescraper.repository")
class ChannelRepositoryTest {

    private @Autowired ChannelRepository channelRepository;

    @Test
    void findChannelByNameEqualsIgnoreCase() throws MalformedURLException {
        Channel expected = Channel.builder().name("Marcos Panadeiro").url(new URL("https://yt.com/pandeiro")).build();

        channelRepository.save(expected);
        Optional<Channel> actual = channelRepository.findChannelByNameEqualsIgnoreCase("Marcos Panadeiro");

        assertEquals(expected, actual.get());
    }
}