package com.marcoas99.youtubescraper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoutubeScraperApplicationTests {

    @Test
    void contextLoads() {
    }

}
