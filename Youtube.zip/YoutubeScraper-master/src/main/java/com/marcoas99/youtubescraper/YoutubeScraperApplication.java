package com.marcoas99.youtubescraper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoutubeScraperApplication {

    public static void main(String[] args) {
        SpringApplication.run(YoutubeScraperApplication.class, args);
    }

}
