package com.marcoas99.youtubescraper.api;

import com.marcoas99.youtubescraper.model.Video;
import com.marcoas99.youtubescraper.repository.VideoRepository;
import lombok.AllArgsConstructor;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@AllArgsConstructor
@Controller
public class VideoController {

        private final VideoRepository repository;

        @QueryMapping
        public List<Video> getAll() {
            return repository.findAll();
        }
}
